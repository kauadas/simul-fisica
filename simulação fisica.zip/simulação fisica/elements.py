constmass=3

elements=dict([
    
    ("0,0,247",dict([
        ("name","hidrogenio"),
        ("U",1.008/constmass)])),

    ("155,0,0",dict([
        ("name","helio"),
        ("U",4/constmass)
    ])),

    ("155,155,155",dict([
        ("name","litio"),
        ("U",7/constmass)
    ])),

    ("0,222,0",dict([
        ("name","berilio"),
        ("U",9/constmass)
    ])),
    ("0,145,0",dict([
        ("name","boro"),
        ("U",10.80/constmass)
    ])),
    ("0,255,0",dict([
        ("name","carbono"),
        ("U",12/constmass)
    ])),
    ("0,0,255",dict([
        ("name","oxigenio"),
        ("U",16/constmass)
    ])),
    
    
    
])

def get_element(element):
    if str(",".join(element)) in elements:
        return elements[str(",".join(element))]

    else:
        points=0
        for element2 in elements:
            points=0
            element2=element2.split(",")
            for id1 in element2:
                for id2 in element:
                    if int(id1) > int(id2):
                        pass

                    else:
                        id1,id2=id2,id1

                    if int(id1)-int(id2) < 50:
                        points+=1

            if points >= 2:
                return elements[",".join(element2)]
                break
            