
colors=dict([('black',(0,0,0))])