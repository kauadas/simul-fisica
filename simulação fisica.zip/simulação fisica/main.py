import pygame
import sys
import elements
import threading
from PIL import Image
from colors import colors
from multiprocessing.pool import ThreadPool

pool=ThreadPool(1)

space_time=[]
c=299792
G=6.67408*(10**-11)

Ga=-0.02
G = G-Ga
win_size=(800,600)
window = pygame.display.set_mode(win_size,pygame.RESIZABLE)

def get_infos(data):
        def maindef(dat,*args):
            print('data: '+data)
            size = Image.open(data).size
            m=0
            for pixel in Image.open(data).getdata():
                newpixel=[]
                for i in pixel:
                    newpixel.append(str(i))
                element=elements.get_element(newpixel)
                m+=element['U']

            
            
            v=(4*3.14*size[0]**3)/3
            d=m/v
            e=m*(c^2)
            obj = [m,d,(size[0],size[1]),e,v]

            return obj

        return pool.apply_async(maindef,(data)).get()

def fisicbody(pos: tuple,data: str):
    obj=get_infos(data)
    size=obj[2]
    print(obj)
    radius=pos[1]/2
    box=pygame.draw.circle(window,(15,0,0),(pos[0],pos[1]),radius)
    sprite=pygame.image.load(data)
    window.blit(sprite,(pos[0]-radius,pos[1]-radius))

    class objclass:
        def __init__(self):
            self.x=pos[0]
            self.y=pos[1]
            self.size=size
            self.old_sprite=data
            self.sprite=data
            
            self.infos = obj
            self.m=self.infos[0]
            self.v=self.infos[4]
            
            self.a=list((0,0))
            self.V=list((0,0))

        def recalc(self):
            self.d=self.m/self.v

            
            self.V=[self.a[0]+self.V[0],self.a[1]+self.V[1]]

            self.x += self.V[0]
            self.y += self.V[1]
            
            if self.x >= win_size[0]:
                self.x=1

            if self.x <= 0:
                self.x=win_size[0]-200

            if self.y >= win_size[1]:
                self.y = 1

            if self.y <= 0:
                self.y=win_size[1]-200

        def update(self):
            if self.sprite != self.old_sprite:
                self.infos=get_infos(self.sprite)
                self.old_sprite=self.sprite

            self.recalc()

            radius=self.size[1]/2
            box=pygame.draw.circle(window,(255,0,0),(self.x,self.y),radius)
            sprite=pygame.image.load(self.sprite)
            window.blit(sprite,(self.x-radius,self.y-radius))

        
        def applyForce(self,value,i: int):
            f=self.m

            if value != 0:
                self.a[i]+=value/f

            else:
                pass
                #self.a[i]=0
                #self.V[i]=0

    return objclass()

def gravity():
    global G
    Const = 200
    
    while True:
        for i in space_time:
            for i2 in space_time:
                if i != i2:

                    

                    Rx=i.x-i2.x
                    Rxp=Rx
                    if Rx < 0:
                        Rxp=Rx*-1

                    Ry=i.y-i2.y
                    Ryp=Ry
                    if Ry < 0:
                        Ryp=Ry*-1

                    R=(Rx**2)+(Ry**2)
                    

                    if not Rxp <= Const:
                        fx=((G*(i.m*i2.m))/(Rx**2))

                    else:
                        fx=0

                
                    if not Ryp <= Const:
                        fy=((G*(i.m*i2.m))/(Ry**2))
                    
                    else:
                        fy=0



                    i.applyForce(fx,0)

                    
                    i.applyForce(fy,1)

                    i2.applyForce(fx*-1,0)

                    i2.applyForce(fy*-1,1)

        if run == False:
            break




def body(pos: tuple, data: str):
    item=fisicbody(pos,data)
    space_time.append(item)

    return space_time[space_time.index(item)]

pygame.display.set_caption('universo')
terra=body((100,100),"cache/sources/earth.png")

terra2=body((300,100),"cache/sources/earth2.png")


run=True

def console():
    global run

    while True:
        cmd=input(" >> ")
        if cmd == "exit":
            run=False
        else:
            try:
                for i in cmd.split(";"):
                    exec(cmd)
            except Exception as e:
                print(e)

        if run == False:
            break


    


threading.Thread(target=console).start()
threading.Thread(target=gravity).start()
def update():
    
    window.fill(colors['black'])
    for i in space_time:
        i.update()
    pygame.display.flip()

while True:
    
    for e in pygame.event.get():
        if e.type == pygame.QUIT or run == False:
            run=False
            sys.exit()

        if e.type == pygame.VIDEORESIZE:
            
            win_size=[e.w,e.h]
            window = pygame.display.set_mode(win_size,pygame.RESIZABLE)


    update()