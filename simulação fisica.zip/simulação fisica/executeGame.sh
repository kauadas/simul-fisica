 
python3 /home/kaua/SES/SES.py execute jwg.pyexe
